//
//  ViewController.m
//  P2PDemo
//
//  Created by apple on 13-3-5.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#include "P2P_API.h"
#import "Adpcm.h"

void _AVDataCallback(long nHandle, int bVideo, char *pData, int len, void *pParam)
{
    NSLog(@"_AVDataCallback... nHandle: %ld, bVideo: %d, len: %d", nHandle, bVideo, len);
    ViewController * videoView = (ViewController*)pParam;
    
    char PCMBuf[2048] = {0};
    
    if (bVideo) {//video data
        PAV_HEAD avhead = (PAV_HEAD)pData;
        if (avhead->len + sizeof(AV_HEAD) != len) {
            return;
        }
        
        if (avhead->type != 3) {
            return;
        }
        
        //pVideo is the video data , one jpeg image
        char *pVideo = pData + sizeof(AV_HEAD);
       
        NSData *image = [[NSData alloc] initWithBytes:pVideo length:avhead->len];
        UIImage *img = [[UIImage alloc] initWithData:image];  
        [videoView performSelectorOnMainThread:@selector(displayImage:) withObject:img waitUntilDone:NO];
        //[img release];
        [image release];
        
    }else {//audio data
        PAV_HEAD avhead = (PAV_HEAD)pData;
        if (avhead->len + sizeof(AV_HEAD) != len) {
            return;
        }
        
        //pAudio is the audio data with the format of adpcm
        char *pAudio = pData + sizeof(AV_HEAD);
        if (avhead->len == 512) {
            CAdpcm adpcm;
            adpcm.ADPCMDecode(pAudio, 512, PCMBuf);
            //PCMBuf is the pcm data, the length is 2048 bytes, you can use for play, 
            
            
        }
        
        
    }    
    
}

void _MessageCallback(long nHandle, int type, char *msg, int len, void *pParam)
{
    NSLog(@"_MessageCallback...nHandle: %ld, type: %d, len: %d", nHandle, type, len);
    
    switch (type) {
        case MSG_TYPE_P2P_MODE:
        {
            int nMode = *((int*)msg);
            switch (nMode) {
                case P2P_MODE_P2P_RELAY:
                    NSLog(@"P2P_MODE_P2P_RELAY");
                    break;
                case P2P_MODE_P2P_CONNECTED:
                    NSLog(@"P2P_MODE_P2P_CONNECTED");
                    break;
                    
                default:
                    break;
            }
        }
            break;
        case MSG_TYPE_P2P_STATUS:
        {
            int nStatus = *((int*)msg);
            
            switch (nStatus) {
                case P2P_STATUS_CONNECTING:
                    NSLog(@"P2P_STATUS_CONNECTING");
                    break;
                case P2P_STATUS_CONNECT_TIME_OUT:
                    NSLog(@"P2P_STATUS_CONNECT_TIME_OUT");
                    break;
                case P2P_STATUS_CONNECT_SUCCESS:
                    NSLog(@"P2P_STATUS_CONNECT_SUCCESS");
                    break;
                case P2P_STATUS_DEVICE_NOT_ON_LINE:
                    NSLog(@"P2P_STATUS_DEVICE_NOT_ON_LINE");
                    break;
                case P2P_STATUS_INVALID_ID:
                    NSLog(@"P2P_STATUS_INVALID_ID");
                    break;
                case P2P_STATUS_DISCONNECTED:
                    NSLog(@"P2P_STATUS_DISCONNECTED");
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        default:
            break;
    }
}

@interface ViewController ()

@end

@implementation ViewController


@synthesize imageView;


- (IBAction)Inital:(id)sender
{
    //P2PAPI_Initial();
    //please contact the company to get the address string of the p2p server
    P2PAPI_InitialWithServer((char*)"EBGAEOBOKHJMHMJMENGKFIEEHBMDHNNEGNEBBCCCBIIHLHLOCIACCJOFHHLLJEKHBFMPLMCHPHMHAGDHJNNHIFBAMC");
}

- (IBAction)CreateInstance:(id)sender
{
    P2PAPI_CreateInstance(&m_lHandle);
}

- (IBAction)SetCallBack:(id)sender
{
    P2PAPI_SetMessageCallBack(m_lHandle, _MessageCallback, self);
    P2PAPI_SetAVDataCallBack(m_lHandle, _AVDataCallback, self);
}

- (IBAction)Connect:(id)sender
{
    P2PAPI_Connect(m_lHandle, (char*)"OBJ-002862-DXJFP", (char*)"admin", (char*)"");
}

- (IBAction)Close:(id)sender
{
    P2PAPI_Close(m_lHandle);
}

- (IBAction)StartVideo:(id)sender
{
    P2PAPI_StartVideo(m_lHandle);
}

- (IBAction)StartAudio:(id)sender
{
    P2PAPI_StartAudio(m_lHandle);
}

- (IBAction)StopVideo:(id)sender
{
    P2PAPI_StopVideo(m_lHandle);
}

- (IBAction)StopAudio:(id)sender
{
    P2PAPI_StopAudio(m_lHandle);
}

- (IBAction)DestroyInstance:(id)sender
{
    P2PAPI_DestroyInstance(m_lHandle);
    m_lHandle = -1;
}

- (IBAction)DeInital:(id)sender
{
    P2PAPI_DeInitial();
}


- (void) displayImage: (UIImage*) image
{
    //NSLog(@"displayImage..");
    imageView.image = image;
    [image release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void) dealloc
{
    self.imageView = nil;
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
