//
//  ViewController.h
//  P2PDemo
//
//  Created by apple on 13-3-5.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
    long m_lHandle;
    
    IBOutlet UIImageView *imageView;
    
}

@property (nonatomic, retain) UIImageView *imageView;

- (IBAction)Inital:(id)sender;
- (IBAction)CreateInstance:(id)sender;
- (IBAction)SetCallBack:(id)sender;
- (IBAction)Connect:(id)sender;
- (IBAction)Close:(id)sender;
- (IBAction)StartVideo:(id)sender;
- (IBAction)StartAudio:(id)sender;
- (IBAction)StopVideo:(id)sender;
- (IBAction)StopAudio:(id)sender;
- (IBAction)DestroyInstance:(id)sender;
- (IBAction)DeInital:(id)sender;



@end
